export const analyticTitleCards = [
    'Analyze these stocks and make the right investment decisions based on the data obtained.',
    'Draw a smooth line across prices using the Moving Average interface in 50 and 200 days period.',
    'Look at the Simple Income, Volatility, Sharp Ratio and IRR calculation in stocks for any period.',
    'The ability to compare two stocks using any of the above calculations and choose the most profitable.'
];