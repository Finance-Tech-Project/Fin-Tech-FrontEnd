import { styled } from "styled-components";

export const TradingViewWidgetContainer = styled.div`
    min-width: 100%;
`;